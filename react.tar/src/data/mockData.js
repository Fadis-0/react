import { tokens } from "../theme";

export const mockDataTeam = [
  {
    id: 1,
    name: "Core i7-9900k",
    price: 439.99,
    quantity: 18,
    category: "PC Hardware",
    state: "for sale",
  },
  {
    id: 2,
    name: "GeForce RTX 3080",
    price: 799.99,
    quantity: 35,
    category: "PC Hardware",
    state: "not for sale",
  },
  {
    id: 3,
    name: "Logitech G Pro Wirless Mouse",
    price: 129.99,
    quantity: 10,
    category: "PC Accessory",
    state: "for sale",
  },
  {
    id: 4,
    name: "Gigabyte AORUS RGB 16GB DDR4",
    price: 619.99,
    quantity: 20,
    category: "PC Hardware",
    state: "for sale",
  },
  {
    id: 5,
    name: "Corsair k95 Platinum Keyboard",
    price: 209.99,
    quantity: 18,
    category: "PC Accessory",
    state: "not for sale",
  },
];